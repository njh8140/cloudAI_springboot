package com.aianalysis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AianalysisApplicationTests {

	@Test
	void contextLoads() {
	}

}
